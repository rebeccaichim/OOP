#ifndef ELECTRICSCOOTEROPERATOR_H
#define ELECTRICSCOOTEROPERATOR_H

#include <iostream>
#include "ElectricScooter.h"

std::ostream& operator<<(std::ostream& os, const domain::ElectricScooter& scooter);

#endif  // ELECTRICSCOOTEROPERATOR_H
